package com.threetier.team1.rollingpaper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RollingpaperApplicationTests {

	@Test
	void contextLoads() {
	}

}
